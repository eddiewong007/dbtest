package demo2;

public class Application {

	public boolean process(String[] words) {
		boolean result = false;
		for (int i = 0; i < words.length; i++) {
			words[i]=reverseCharacters(words[i]);
			//System.out.println(words[i]);			
		}
		if (isMightyMouse(words)) {
			//System.out.println("...here he comes to save the day.");
			result = true;
		}
		return result;
	}

	private String reverseCharacters(String forward) {
		String reverse = "";
		for (int j = forward.length(); j > 0; j--) {
			reverse += forward.substring(j - 1, j);
		}
		return reverse;
	}

	private boolean isMightyMouse(String[] names) {
		boolean rval = false;
		if (names.length == 2) {
			if (names[0].toLowerCase().equals("mighty")
					&& names[1].toLowerCase().equals("mouse"))
				rval = true;
		}
		return rval;
	}
}
