package demo2;

public class MethodReafctoryDemo {
	String name="";
	
	void printOwing() {
	
		double outstanding = 0.0;

		// print banner
		printBanner();
		
		
		// calculate outstanding		
		outstanding = calculate(outstanding);

		// print details
		printDetails(outstanding);

	}



	private double calculate(double outstanding) {
		for(int i=10;i<20;i++){
			outstanding += i;
		}
		return outstanding;
	}



	private void printDetails(double outstanding) {
		System.out.println("name:" + name);
		System.out.println("amount" + outstanding);
	}



	private void printBanner() {
		System.out.println("**************************");
		System.out.println("***** Customer Owes ******");
		System.out.println("**************************");
	}

	
	
	private void testMethod(){
		printBanner();
	}

}
