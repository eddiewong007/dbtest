package com.orders;

public class Product {
	private String id, name;
	private Color color;
	private float price;
	private int size;
	
	public Product(String id, String name, Color color, float price, int size) {
		this.id = id;
		this.name = name;
		this.color = color;
		this.price = price;
		this.size = size;
	}
	
	public String getID() {
		return id;
	}
	
	public Color getColor() {
		return color;
	}

	public float getPrice() {
		return price;
	}

	public int getSize() {
		return size;
	}

	public Object getCategory() {
		return "toys";
	}

	public String getName() {
		return name;
	}
}
