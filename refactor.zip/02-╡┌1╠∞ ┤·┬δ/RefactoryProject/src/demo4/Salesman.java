package demo4;

public class Salesman extends Employee {
}
