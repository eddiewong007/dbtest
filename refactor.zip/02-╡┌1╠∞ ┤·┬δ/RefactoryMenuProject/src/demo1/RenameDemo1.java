package demo1;

public class RenameDemo1 {

	/**
	 * @deprecated Use {@link #testCall(Object)} instead
	 */
	public void testCall() {
		testCall(null);
	}

	public void testCall(Object newParam) {
		int _height1 = 12;
		int _width = 15;
		
		double temp = 2 * (_height1 + _width);
		System.out.println(temp);

		temp = _height1 * _width;
		System.out.println(temp);
	}
	
	public void callMethod(){
		testCall(null);
	}
}