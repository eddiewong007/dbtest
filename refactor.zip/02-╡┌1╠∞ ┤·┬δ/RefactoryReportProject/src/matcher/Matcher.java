package matcher;

public class Matcher {
    public Matcher() {}
    public boolean match(int[] expected, int[] actual, 
        int clipLimit, int delta) 
    {

        // �ҳ������󡱵�ֵ  Clip "too-large" values  
        for (int i = 0; i < actual.length; i++)
            if (actual[i] > clipLimit)
                actual[i] = clipLimit;

        //�鿴���Ȳ���    Check for length differences
        if (actual.length != expected.length)
            return false;

        //���expected +/ delta ��Χ��ÿһ��   
        //Check that each entry within expected +/- delta
        for (int i = 0; i < actual.length; i++)
            if (Math.abs(expected[i] - actual[i]) > delta)
                return false;

        return true;
    }
}