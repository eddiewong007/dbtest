package com.orders.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.orders.Color;
import com.orders.Order;
import com.orders.Product;

public class OrderTest {
	private Product product;
	private Order order;

	@Before 
	public void createProduct() {
		product = new Product("productID", "firstProduct", Color.white, 9.99F, 33);
		order = new Order("0");
	}
	
	@Test
	public void addProductIncrementsCount() {
		assertEquals(0, order.getProductCount());
		order.addProduct(product);
		assertEquals(1, order.getProductCount());
	}
	
	@Test
	public void addProductsRetainsProducts() {
		order.addProduct(product);
		Product secondProduct = new Product("productID", "secondProduct", Color.white, 9.99F, 33);
		order.addProduct(secondProduct);
		assertEquals("firstProduct", order.getProduct(0).getName());
		assertEquals("secondProduct", order.getProduct(1).getName());
	}
}
