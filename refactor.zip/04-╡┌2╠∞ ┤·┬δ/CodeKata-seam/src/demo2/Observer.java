package demo2;

public interface Observer {
	public void update(WeatherEvent event);
}

