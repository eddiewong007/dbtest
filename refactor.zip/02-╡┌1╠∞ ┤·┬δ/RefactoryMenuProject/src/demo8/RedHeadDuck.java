package demo8;

public class RedHeadDuck  {

	RedHeadDuckData data = new RedHeadDuckData();


	public void display() {
		System.out.print(data.getName());
		System.out.println("I'm a real Red Headed duck");
	}
	
	public void swim(Point parameterObject) {
		System.out.print(parameterObject.getX());
		System.out.println("All ducks float, even decoys!");
	}
	
	
	public void fly(int x,int y) {
		System.out.println("I'm flying with a rocket");
	}
	
	
}
