package demo11;

import java.awt.Frame;  
import java.awt.event.WindowAdapter;  
import java.awt.event.WindowEvent;  
  
public class Anonymous extends Frame{  
    public Anonymous(){  
        this.setTitle("Ӧ�ñ���");  
        addWindowListener(new WindowAdapter(){  
            public void windowClosing(WindowEvent e){  
                dispose();  
                System.exit(0);  
            }  
        });  
    }  
  
}  
