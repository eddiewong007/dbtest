package demo8;

public class Employee {
	private String _id;
	private String _name;
	private int _annualCost;
	private int age;

	public Employee(String name, String id, int annualCost) {
		_name = name;
		_id = id;
		_annualCost = annualCost;
	}

	
	void test(){
		age = 0;
		System.out.print("age=  "+age);
	}
}
