package demo10;

public abstract  class Employee implements IEmploy {
	String id;
	String name;
	double baseSalary;
	
	/* (non-Javadoc)
	 * @see demo10.IEmploy#getBaseSalary()
	 */
	@Override
	public double getBaseSalary() {
		return baseSalary;
	}
	/* (non-Javadoc)
	 * @see demo10.IEmploy#setBaseSalary(double)
	 */
	@Override
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}
	/* (non-Javadoc)
	 * @see demo10.IEmploy#getId()
	 */
	@Override
	public String getId() {
		return id;
	}
	/* (non-Javadoc)
	 * @see demo10.IEmploy#setId(java.lang.String)
	 */
	@Override
	public void setId(String id) {
		this.id = id;
	}
	/* (non-Javadoc)
	 * @see demo10.IEmploy#getName()
	 */
	@Override
	public String getName() {
		return name;
	}
	/* (non-Javadoc)
	 * @see demo10.IEmploy#setName(java.lang.String)
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}
	
}
