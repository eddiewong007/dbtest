package demo0;

import java.util.HashMap;

public class QueryString {
	HashMap<String, String> valuePairs=null;

	public QueryString(String quequeryString) {
		if (quequeryString == null)
			throw new NullPointerException();
		valuePairs=parse(quequeryString);
	}

	private HashMap<String, String> parse(String queryString) {
		HashMap<String, String> tmpPairs=new HashMap<String, String>();
		if("".equals(queryString)){
			return tmpPairs;
		}
		String[] pairs=	queryString.split("&");
		for (String pair : pairs) {
			String[] nameAndValue = pair.split("=");
			tmpPairs.put(nameAndValue[0],nameAndValue[1]);
		}
		return tmpPairs;
	}

	public int count() {
		return valuePairs.size();
	}

	public String valueFor(String name) {
		String value=valuePairs.get(name);
		if(value!=null){
			return value;
		}else{
			throw new RuntimeException("name=" + name + "not  found");
		}
		
	}

 }
