package demo4;

import java.util.Date;

public class ParameterRefactory {
	double getFlowBetween (DateBetweenBean parameterObject) {

	       double result = 0;
	       result+=10;
	       System.out.print("Date start "+parameterObject.getStart());
	       System.out.print("Date end"+parameterObject.getEnd());
	       return result;
	       
	}
	
	 void setFlowBetween (DateBetweenBean parameterObject) {
		 System.out.print("Date start "+parameterObject.getStart());
	     System.out.print("Date end"+parameterObject.getEnd());
	}
}
