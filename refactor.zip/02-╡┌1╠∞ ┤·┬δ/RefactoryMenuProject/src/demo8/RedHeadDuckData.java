package demo8;

public class RedHeadDuckData {
	private String name;
	private String age;

	public RedHeadDuckData() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
}