package demo2;

import Driver.CVenderDriver;

public class CDisplayAdapter extends CVenderDriver implements Observer {

	public void update(WeatherEvent event) {
		super.updateHumidity(event.getHumidity());
		super.updatePressure(event.getPressure());
		super.updateTemperature(event.getTemp());				
	}

}
