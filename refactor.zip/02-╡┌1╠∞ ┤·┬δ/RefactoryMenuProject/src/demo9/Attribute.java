package demo9;

public class Attribute {

	private String name;
	private String value;

	public Attribute(String name, String value) {
		this.name = name;
		this.value = value;
	}

	public String toString() {
		return "{" +name+"='" + value+ "'" +"}";
	}

}
