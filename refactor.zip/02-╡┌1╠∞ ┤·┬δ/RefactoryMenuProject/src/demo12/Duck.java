package demo12;

public class Duck {

	DuckData data = new DuckData();

	public Duck() {
		super();
	}

	public void display(String name) {
		int value;
		System.out.println("I'm a duck Decoy");
	}

}