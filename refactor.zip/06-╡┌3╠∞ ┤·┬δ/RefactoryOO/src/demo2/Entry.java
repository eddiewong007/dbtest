package demo2;

public class Entry {

	protected String _name;

	public Entry() {
		super();
	}

	public String getName() {
		return _name;
	}

}