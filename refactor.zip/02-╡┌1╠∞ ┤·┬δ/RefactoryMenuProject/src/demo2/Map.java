package demo2;

public class Map {
	private static int INITIAL_CAPACITY = 10;
	
	protected Object[] values = new Object[INITIAL_CAPACITY];
	
	private int size = 0;
	
	public boolean contains(Object value) {
		for (int i = 0; i < size; i++)
			if ((value == null && values[i] == null)
				|| (values[i] != null && values[i].equals(value)))
				return true;
		return false;
	}
	
	
}
