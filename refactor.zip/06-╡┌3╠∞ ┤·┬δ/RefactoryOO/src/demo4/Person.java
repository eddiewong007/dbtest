package demo4;

public class Person {
	private String name;
	private PhoneNumber number = new PhoneNumber();

	

	//  private TelephoneNumber officeTelephone = new TelephoneNumber();
	
	public String getName() {
		return name;
	}

	public String getTelephoneNumber() {
		return ("(" + number.getOfficeAreaCode() + ") " + number.getOfficeNumber());
	}

	
}
