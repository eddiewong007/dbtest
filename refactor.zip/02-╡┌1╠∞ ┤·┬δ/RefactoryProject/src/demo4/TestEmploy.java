package demo4;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestEmploy {

	@Test
	public void test() {
		Employee engineer=new Engineer();	
		engineer.setName("����");
		engineer.setBaseSalary(100);
		
		StringBuffer engineerxml=new StringBuffer();
		engineerxml.append("<employee name=\"����\" department=\"Engineering\" salary=100.0>");
		assertEquals(engineerxml.toString(),engineer.asXML());
		
		
		Manager manager=new Manager();		
		manager.setName("����");
		manager.setBaseSalary(2000);
		
		StringBuffer managerxml=new StringBuffer();
		managerxml.append("<employee name=\"����\" department=\"Management\" salary=23000.0>");
		assertEquals(managerxml.toString(),manager.asXML());
				
		Salesman salesman=new Salesman();
		salesman.setName("������");
		salesman.setBaseSalary(2000);
		StringBuffer salesmanxml=new StringBuffer();
		salesmanxml.append("<employee name=\"������\" department=\"Sales\" salary=3000.0>");
		assertEquals(salesmanxml.toString(),salesman.asXML());		
	}

}
