package demo9;

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public class TagNodeTest {

	@Test
	public void testAtrribute() {
		TagNode tagnode=new TagNode("name");
		tagnode.addAttribute("name", "value");
		
		assertEquals("{name='value'}", tagnode.toString());		
	}
}
