package demo11.example;


public enum Job {
	PROGRAM, TEST, SLEEP, MARKET, INTEGRATE, DESIGN, SELL, MANAGE
}
