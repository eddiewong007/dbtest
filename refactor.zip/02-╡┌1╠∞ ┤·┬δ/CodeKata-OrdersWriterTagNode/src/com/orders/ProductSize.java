package com.orders;

public class ProductSize {
	public final static int SMALL = 0;
	public final static int MEDIUM = 1;
	public final static int LARGE = 2;
	public final static int NOT_APPLICABLE = 3;
	
}
