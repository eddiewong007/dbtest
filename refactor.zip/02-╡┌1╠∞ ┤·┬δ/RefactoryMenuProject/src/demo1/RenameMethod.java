package demo1;

public class RenameMethod {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RenameDemo1 demo=new RenameDemo1();
		demo.testCall(null);

	}

}
