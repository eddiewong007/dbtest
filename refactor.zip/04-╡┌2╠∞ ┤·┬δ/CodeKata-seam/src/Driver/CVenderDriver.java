package Driver;

public class CVenderDriver {

	public void updateTemperature(float temperature) {

	}

	public void updateHumidity(float humidity) {

	}

	public void updatePressure(float pressure) {

	}
}
