package Driver;

public class AVenderDriver {
	public void update(float temp, float humidity, float pressure){
		
	}
}
