
package com.orders;

import java.util.List;
import java.util.ArrayList;

import com.orders.Product;

public class Order {
	private String id;
	private List<Product> products = new ArrayList<Product>();

	public Order(String orderId) {
		id = orderId;
	}

	public void addProduct(Product productToAdd) {
		products.add(productToAdd);
	}

	public Object getOrderId() {
		return id;
	}

	public int getProductCount() {
		return products.size();
	}

	public Product getProduct(int index) {
		return (Product)products.get(index);
	}
}
