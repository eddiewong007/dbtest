package demo10;

public class Manager extends Employee {
	public String asXML() {
	    StringBuffer buf = new StringBuffer();
	    buf.append("<employee name=\"");
	    buf.append(getName());
	    buf.append("\" department=\"Management\"");
	    buf.append(" salary="+calculatePay()+">");	   
	    return buf.toString();
	  }
	
	 

	public double  calculatePay () {
		//��н+���+��Ȩ
	     return  baseSalary+1000+20000;
	}
}
