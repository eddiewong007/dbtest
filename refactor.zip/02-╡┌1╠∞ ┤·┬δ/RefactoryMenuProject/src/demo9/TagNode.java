package demo9;

import java.util.List;


public class TagNode {
	private String tagName="";
	private String tagValue="";
	private String attributes="";

	List<TagNode> children;

	public TagNode(String name) {		
		this.tagName = name;
	}
	
	public void addAttribute(String name,String value){	
		attributes+=new Attribute(name, value).toString();
	}

	public void addValue(String value){
		this.tagValue=value;
	}

	public String toString(){
		return attributes;
	}
	
}
