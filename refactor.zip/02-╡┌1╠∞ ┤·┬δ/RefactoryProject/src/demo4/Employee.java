package demo4;

public abstract  class Employee {
	String id;
	String name;
	double baseSalary;
	
	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String asXML() {
	    StringBuffer buf = new StringBuffer();
	    buf.append("<employee name=\"");
	    buf.append(getName());
	    buf.append("\" department=\"Engineering\"");
	    buf.append(" salary="+calculatePay()+">");	   
	    return buf.toString();
	  }
	public double calculatePay() {
	     return  baseSalary;
	}
	
}
