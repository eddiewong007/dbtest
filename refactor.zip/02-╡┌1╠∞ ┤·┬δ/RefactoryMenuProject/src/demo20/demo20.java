package demo20;

public class demo20 {
	private static final double CONSTANT_VALUE = 9.81;


	//static final double GRAVITATIONAL_CONSTANT = 9.81;

	double potentialEnergy(double mass, double height) {
	       return mass*CONSTANT_VALUE*height;

	}

	double potentialEnergy2(double mass, double height) {
		return mass *CONSTANT_VALUE* height;
	}

	
     private String  _query;

	
	public int count() {
		String[] pairs = _query.split("&");
		return 0;
	}

	public void valueFor(String name) {
		String[] pairs = _query.split("&");		
	}
}
