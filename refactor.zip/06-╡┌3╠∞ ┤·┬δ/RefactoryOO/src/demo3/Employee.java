package demo3;

public class Employee implements IEmployee {
	private String _id;
	private String _name;
	private int _annualCost;

	public Employee(String name, String id, int annualCost) {
		_name = name;
		_id = id;
		_annualCost = annualCost;
	}

	/* (non-Javadoc)
	 * @see demo3.IEmployee#getAnnualCost()
	 */
	@Override
	public int getAnnualCost() {
		return _annualCost;
	}

	/* (non-Javadoc)
	 * @see demo3.IEmployee#getId()
	 */
	@Override
	public String getId() {
		return _id;
	}

	public String getName() {
		return _name;
	}
	
	public int getRate(){
		return 0;
	}

	public boolean hasSpecialSkill(){
		return true;
	}
}
