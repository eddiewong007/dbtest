package demo1;

public class OneLoop {
	private Student[] students;  
	  
	void setStudents(Student[] students){
		this.students=students;
	}
    void printValues() {  
        double averageAge = 0; // ƽ������  
        int totalGrade = 0; // �ܳɼ�  
  
        for (int i = 0; i < students.length; i++) {  
            averageAge += students[i].getAge();  
            totalGrade += students[i].getGrade();  
        }  
        averageAge = averageAge / students.length;  
  
        System.out.println("averageAge = "+averageAge);  
        System.out.println("totalGrade = "+totalGrade);  
    }  
}
