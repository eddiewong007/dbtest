package demo2;

import Driver.AVenderDriver;

public class ADisplayAdapter implements Observer {
	AVenderDriver aVenderDriver=new AVenderDriver();
	
	public void update(WeatherEvent event) {
		
		aVenderDriver.update(event.getTemp(), event.getHumidity(), event.getPressure());
		

	}

}
