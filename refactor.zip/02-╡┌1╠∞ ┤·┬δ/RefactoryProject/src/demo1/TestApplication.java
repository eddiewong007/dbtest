package demo1;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * A dummy test-case to demonstrate how to use a test-suite.
 * 
 * @version $Id: TestCaseA.java 552 2010-03-06 11:48:47Z paranoid12 $
 */
public class TestApplication {
	@Test
	public void testProcess() {
		Application myApp = new Application();	
		
		String[] words={"abc","cde","edf","fgh"};
		testAssertFalse(myApp, words);
		
		String[] words2={"ythgim","esuom"};		
		assertTrue(myApp.process(words2));
		
		String[] words3={"ythgim","esuom","abc"};		
		testAssertFalse(myApp, words3);
	}

	private void testAssertFalse(Application myApp, String[] words) {
		assertFalse(myApp.process(words));
	}
}
