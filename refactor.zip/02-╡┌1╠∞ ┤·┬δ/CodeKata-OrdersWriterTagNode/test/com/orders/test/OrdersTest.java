
package com.orders.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.orders.Order;
import com.orders.Orders;

public class OrdersTest {
	private Orders orders;

	@Before
	public void createOrders() {
		orders = new Orders();
	}
	
	@Test
	public void addOrderIncrementsCount() {
		assertEquals(0, orders.getOrderCount());
		orders.addOrder(new Order("0"));
		assertEquals(1, orders.getOrderCount());
	}
	
	@Test
	public void ordersRetainedInOrder() {
		orders.addOrder(new Order("0"));
		orders.addOrder(new Order("1"));
		assertEquals("0", orders.getOrder(0).getOrderId());
		assertEquals("1", orders.getOrder(1).getOrderId());
	}
}
