
package com.orders;

public class Color {
	private Color() {
		super();
	}
	
	public static Color red = new Color();
	public static Color white = new Color();
	public static Color pink = new Color();
	public static Color yellow = new Color();
}
