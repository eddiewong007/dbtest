package demo11.example;


import java.util.EnumSet;

public class Manager extends Employee {
	public EnumSet<Job> responsibilities() {
		return EnumSet.of(Job.MANAGE, Job.MARKET, Job.SELL);
	}
}


