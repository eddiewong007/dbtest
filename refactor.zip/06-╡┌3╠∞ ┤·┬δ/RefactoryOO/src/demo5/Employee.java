package demo5;

public abstract  class Employee {
	double baseSalary;
	
	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}
	public double calculatePay() {
	     return  baseSalary;
	}
	
}
