package demo4;

public class Engineer extends Employee {

}
