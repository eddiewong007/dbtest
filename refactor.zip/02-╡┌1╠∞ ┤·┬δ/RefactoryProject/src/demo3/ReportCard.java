package demo3;

import java.util.*;

public class ReportCard {
    private static final int GRADE_LEVEL = 64;
    private static final char FAIL_GRADE = 'F';
	public String studentName;
    public ArrayList clines;

    public String printReport(){
    	StringBuffer reportinfo=new  StringBuffer();
    	printReportHeader(reportinfo);
        printReportLines(reportinfo);
        double avg = calculateAvg();
        printReportFooter(reportinfo, avg);
        
        return reportinfo.toString();
    }

	private double calculateAvg() {
		Iterator grades = clines.iterator();
        CourseGrade grade;
		double sum = 0.0;
        double avg = 0.0;
        while(grades.hasNext()) {
        	 grade = (CourseGrade)grades.next();
			if(!(grade.grade==FAIL_GRADE)) {
                 sum = sum + grade.grade-GRADE_LEVEL;
             }
         }
        avg = sum / clines.size();
		return avg;
	}

	private void printReportLines(StringBuffer reportinfo) {
		Iterator grades = clines.iterator();
        CourseGrade grade;
        while(grades.hasNext()) {
           grade = (CourseGrade)grades.next();
            reportinfo.append(grade.title + "            " +
                                          grade.grade+"\n");
        }
	}

	private void printReportFooter(StringBuffer reportinfo, double avg) {
		reportinfo.append("-------------------------------"+"\n");
        reportinfo.append("Grade Point Average = " + avg+"\n");
	}

	private void printReportHeader(StringBuffer reportinfo) {
		reportinfo.append("Report card for " + studentName +"\n");
        reportinfo.append("-------------------------------"+"\n");
        reportinfo.append("Course Title              Grade"+"\n");
	}
}

class CourseGrade{
    public String title;
    public char grade;
}
