package demo11.example;


import java.util.EnumSet;

public abstract class Employee {
	protected EnumSet<Job> jobs;

	public abstract EnumSet<Job> responsibilities();

	private int jobsCompleted = 0;
	private int jobsSkipped = 0;

	public int jobsCompletedCount() {
		return jobsCompleted;
	}

	public int jobsSkippedCount() {
		return jobsSkipped;
	}

	public void performJob(Job job) {
		if (responsibilities().contains(job))
			jobsCompleted++;
		else
			jobsSkipped++;
	}
}
