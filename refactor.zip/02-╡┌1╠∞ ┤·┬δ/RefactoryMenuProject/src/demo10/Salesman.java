package demo10;

public class Salesman extends Employee {
	public String asXML() {
	    StringBuffer buf = new StringBuffer();
	    buf.append("<employee name=\"");
	    buf.append(getName());
	    buf.append("\" department=\"Sales\"");
	    buf.append(" salary="+calculatePay()+">");	   
	    return buf.toString();
	  }
	
	 

	public double  calculatePay () {
		//���
	     return  baseSalary+1000;
	}
}
