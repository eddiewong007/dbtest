package demo1;

public class TwoLoop {
	private Student[] students;  
	
	void setStudents(Student[] students){
		this.students=students;
	}
    void printValues() {          
        System.out.println("averageAge = "+averageAge());  
        System.out.println("totalGrade = "+totalGrade());  
    }  
  
    private double averageAge() {  
        double result = 0; // ƽ������  
        for (int i = 0; i < students.length; i++) {  
            result += students[i].getAge();  
        }  
        return result / students.length;  
    }  
  
    private int totalGrade() {  
        int result = 0; // �ܳɼ�  
        for (int i = 0; i < students.length; i++) {  
            result += students[i].getGrade();  
        }  
        return result;  
    }  
}
