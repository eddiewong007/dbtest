package demo1;

public class Looptest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//���ԵĴ���
		int testcasecount=10;
		
		//���Ե�ѭ����������
		int looptotals=1000000;
		
		Student[] students=new Student[looptotals];
		for(int i=0;i<looptotals;i++){
			Student student=new Student(1,1);	
			students[i]=student;
		}
		
		OneLoop oneLoop=new OneLoop();
		oneLoop.setStudents(students);
		
		TwoLoop twoLoop=new TwoLoop();
		twoLoop.setStudents(students);
		
		for(int j=0;j<testcasecount;j++){
			System.out.println(  "***********��"+j+"�β���*****************"  );
			Long beginTime =    System.currentTimeMillis() ;
			
			oneLoop.printValues();
			
			long endTime =  System.currentTimeMillis();
			long coustTime  =  endTime - beginTime;					
			System.out.println(  "һ��ѭ��ִ��ʱ�䣨���룩:" +coustTime  );
		    
			
			
			Long beginTime2 =    System.currentTimeMillis() ;
			twoLoop.printValues();
			long endTime2 =  System.currentTimeMillis();
			long coustTime2  =  endTime2 - beginTime2;
			
			System.out.println(  "����ѭ��ִ��ʱ�䣨���룩:" +coustTime2  );
			System.out.println(  "**********************************"  );
		}
		

	}

}
