package demo10;

public class Engineer extends Employee {
	
	public String asXML() {
	    StringBuffer buf = new StringBuffer();
	    buf.append("<employee name=\"");
	    buf.append(getName());
	    buf.append("\" department=\"Engineering\"");
	    buf.append(" salary="+calculatePay()+">");	   
	    return buf.toString();
	  }
	
	 

	public double  calculatePay () {
	     return  baseSalary;
	}

}
