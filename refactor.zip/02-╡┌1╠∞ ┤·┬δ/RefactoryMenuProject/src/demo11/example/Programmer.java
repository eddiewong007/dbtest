package demo11.example;


import java.util.EnumSet;
public class Programmer extends Employee {
	@Override
	public EnumSet<Job> responsibilities() {
		return EnumSet.of(Job.TEST, Job.PROGRAM, Job.INTEGRATE, Job.DESIGN);
	}
}


