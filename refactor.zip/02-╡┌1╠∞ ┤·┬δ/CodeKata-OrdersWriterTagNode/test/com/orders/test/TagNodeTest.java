package com.orders.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.orders.TagNode;

public class TagNodeTest {
	
	@Test
	public void oneElementTree() {
		String expected =
		"<orders>" +
		"</orders>";
		TagNode orders = new TagNode("orders");
		assertEquals("orders xml", expected, orders.toString());
	}
	
	@Test
	public void treeWithAttributes() {
		String expected =
		"<orders>" +
			"<order number='123'>" +
			"</order>" +
		"</orders>";
		TagNode orders = new TagNode("orders");
		TagNode order  = new TagNode("order");
		order.addAttribute("number", "123");
		orders.add(order);
		assertEquals("orders xml", expected, orders.toString());
	}
	
	@Test
	public void treeWithValues() {
		String expected =
		"<orders>" +
			"<order number='123'>" +
			"carDoor" + 
			"</order>" +
		"</orders>";
		TagNode orders = new TagNode("orders");
		TagNode order  = new TagNode("order");
		order.addAttribute("number", "123");
		order.addValue("carDoor");
		orders.add(order);
		assertEquals("orders xml", expected, orders.toString());
	}
	
	@Test
	public void obtainValue() {
		TagNode root = new TagNode("root");
		String EXPECTED_VALUE = "a value";
		root.addValue(EXPECTED_VALUE);
		assertEquals(EXPECTED_VALUE, root.getValue());
	}
}
