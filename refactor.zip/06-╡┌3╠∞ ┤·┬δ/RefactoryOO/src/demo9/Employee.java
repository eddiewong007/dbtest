package demo9;

import java.util.Date;

public class Employee {
	public static Employee createEmployee(String name, String id, int annualCost) {
		return new Employee(name, id, annualCost);
	}

	private String _id;
	private String _name;
	private int _annualCost;

	private Employee(String name, String id, int annualCost) {
		_name = name;
		_id = id;
		_annualCost = annualCost;
	}
}
