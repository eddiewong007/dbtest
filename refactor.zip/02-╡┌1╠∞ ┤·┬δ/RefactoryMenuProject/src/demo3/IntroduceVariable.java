package demo3;

public class IntroduceVariable {
	String platform = "MAC";
	String browser = "IE";
	int resize = 13;

	public void test() {
		final boolean isMacOs = platform.toUpperCase().indexOf("MAC") > -1;
		final boolean isIEBrowser = browser.toUpperCase().indexOf("IE") > -1;
		final boolean wasResized = resize > 0;
		
		if (isMacOs && isIEBrowser && wasResized) {

			System.out.print("THis is a test");

		}

	}
}

/*
 *  
 * final boolean isMacOs     = platform.toUpperCase().indexOf("MAC") > -1;
   final boolean isIEBrowser = browser.toUpperCase().indexOf("IE")  > -1;
   final boolean wasResized  = resize > 0;

   if (isMacOs && isIEBrowser &&  wasResized) {
       // do something
   }
  */
