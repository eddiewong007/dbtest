package demo1;

public class Student {
	
	public Student(int age, int grade) {		
		this.age = age;
		this.grade = grade;
	}

	/** 
     * ���� 
     */  
    private int age;  
    /** 
     * �ɼ� 
     */  
    private int grade;  
      
    public int getAge() {  
        return age;  
    }  
  
    public void setAge(int age) {  
        this.age = age;  
    }  
  
    public int getGrade() {  
        return grade;  
    }  
  
    public void setGrade(int grade) {  
        this.grade = grade;  
    }  
}
