package demo3;

public interface IEmployee {

	int getAnnualCost();

	String getId();

}