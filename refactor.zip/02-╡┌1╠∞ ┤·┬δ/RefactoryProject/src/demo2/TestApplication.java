package demo2;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * A dummy test-case to demonstrate how to use a test-suite.
 * 
 * @version $Id: TestCaseA.java 552 2010-03-06 11:48:47Z paranoid12 $
 */
public class TestApplication {
	@Test
	public void testProcess() {
		String[] words={"abc","cde","edf","fgh"};
		Application myApp = new Application();		
		assertFalse(myApp.process(words));
		
		String[] words2={"ythgim","esuom"};		
		assertTrue(myApp.process(words2));
		
		String[] words3={"ythgim","esuom","abc"};		
		assertFalse(myApp.process(words3));
	}
}
