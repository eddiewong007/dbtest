package demo1;

import Driver.*;

public class WeatherSubject {
	private float temperature;
	private float humidity;
	private float pressure;
	
	
	public void setMeasurements() {
		//�Ӵ�������ȡ�������
		this.temperature = temperature;
		this.humidity = humidity;
		this.pressure = pressure;
		
		AVenderDriver aDriver=new AVenderDriver();
		BVenderDriver bDriver=new BVenderDriver();
		CVenderDriver cDriver=new CVenderDriver();
		
		//LED ���� A��ʾ
		aDriver.update(temperature, humidity, pressure);
		//LED ���� A��ʾ
		BVenderDriver.DisplayParameter data=null;		
		bDriver.display(data);
		//LED ����C��ʾ
		cDriver.updateHumidity(humidity);
		cDriver.updatePressure(pressure);
		cDriver.updateTemperature(temperature);
		
	}
	
	// other WeatherData methods here
	
	public float getTemperature() {
		return temperature;
	}
	
	public float getHumidity() {
		return humidity;
	}
	public float getPressure() {
		return pressure;
	}
}
