package demo4;

public class Manager extends Employee {
}
