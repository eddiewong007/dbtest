package demo1;

public class Account {
	AccountType _type;
	int _daysOverdrawn;

	double bankCharge() {
		double result = 4.5;
		if (_daysOverdrawn > 0)
			result += _type.overdraftCharge(this);
		return result;
	}
}
