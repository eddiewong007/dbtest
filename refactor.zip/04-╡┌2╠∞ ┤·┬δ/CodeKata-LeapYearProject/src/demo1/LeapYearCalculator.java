package demo1;

public class LeapYearCalculator {

	public static boolean isLeapYear(int typicalLeapYear) {
		// TODO Auto-generated method stub
		return false;
	}

}
