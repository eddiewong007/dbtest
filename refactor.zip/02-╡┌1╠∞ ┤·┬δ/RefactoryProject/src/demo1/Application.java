package demo1;

public class Application {

	private static final String MOUSE_VALUE = "mouse";
	private static final String MIGHTY_VALUE = "mighty";
	private static final int WORD_LENGTH = 2;

	public boolean process(String[] words) {
		boolean result = false;

		// Loop through the array of Strings
		reverseWords(words);

		// Test for two particular Strings
		result = isEqualTwoStrings(words, result);
		return result;
	}

	private boolean isEqualTwoStrings(String[] words, boolean result) {
		if (words.length == WORD_LENGTH) {
			if (words[0].toLowerCase().equals(MIGHTY_VALUE)
					&& words[1].toLowerCase().equals(MOUSE_VALUE)) {				
				result = true;
			}
		}
		return result;
	}

	private void reverseWords(String[] words) {
		for (int i = 0; i < words.length; i++) {
			String argument = "";
			// Reverse the characters in each String
			for (int j = words[i].length(); j > 0; j--) {
				argument += words[i].substring(j - 1, j);
			}			
			words[i]=argument;
		}
	}
}
