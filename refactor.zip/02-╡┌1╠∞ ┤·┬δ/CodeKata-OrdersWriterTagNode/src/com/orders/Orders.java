
package com.orders;

import java.util.List;
import java.util.ArrayList;

public class Orders {
	private List<Order> orders = new ArrayList<Order>();

	public void addOrder(Order order) {
		orders.add(order);
	}

	public int getOrderCount() {
		return orders.size();
	}

	public Order getOrder(int index) {
		return (Order)orders.get(index);
	}
}
