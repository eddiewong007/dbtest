package utils;

public class List {
	private static final int SIZE_INCREMENT_VALUE = 10;
	private Object[] elements = new Object[10];
	private int size = 0;
	private boolean readOnly;

	public boolean isEmpty() {
		return size == 0;
	}

	public void add(Object element) {
		if (readOnly) {
			return;
		}
		if (shouldGrow()) {
			grow();
		}
		addElement(element);
	}

	private boolean shouldGrow() {
		return size+1 > elements.length;
	}

	private void addElement(Object element) {
		elements[size++] = element;
	}

	private void grow() {
		Object[] newElements = new Object[elements.length + SIZE_INCREMENT_VALUE];
		copyTo(newElements);
		elements = newElements;
	}

	private void copyTo(Object[] newElements) {
		for (int i = 0; i < size; i++)
			newElements[i] = elements[i];
	}

	public void addAll(List l) {
		for (int i = 0; i < l.size(); i++) {
			if (!contains(l.get(i))) {
				add(l.get(i));
			}
		}

	}

	public boolean contains(Object element) {
		for (int i = 0; i < size; i++)
			if (elements[i].equals(element))
				return true;
		return false;
	}

	public int size() {
		return size;
	}

	public boolean remove(Object element) {
		if (readOnly)
			return false;
		else
			for (int i = 0; i < size; i++) {
				final boolean isRemoveElement = elements[i].equals(element);
				if (isRemoveElement) {
					removeElement(i);
					addRestElements();
					return true;
				}
			}
		return false;
	}

	private void addRestElements() {
		Object[] newElements = new Object[size - 1];
		int k = 0;
		for (int j = 0; j < size; j++) {
			if (elements[j] != null)
				newElements[k++] = elements[j];
		}
		size--;
		elements = newElements;
	}

	private void removeElement(int i) {
		elements[i] = null;
	}

	public Object get(int i) {
		return elements[i];
	}

	public int capacity() {
		return elements.length;
	}

	public void set(int i, Object value) {
		if (!readOnly) {
			if (i >= size)
				throw new ArrayIndexOutOfBoundsException();
			elements[i] = value;
		}
	}

	public void setReadOnly(boolean b) {
		readOnly = b;
	}
}
