package com.code;

public class StringCalculator {

	private static final int MAX_VALUE = 1000;

	public static int add(String number) {
		int sum=0;
		if(isNull(number)){
			return 0;
		}
		if(isEmpty(number)){
			return 0;
		}
		String[] splitStrings = splitString(number);
		for (String str : splitStrings) {
			int num;
			try {
				num=Integer.parseInt(str);
			} catch (Exception e) {
				throw new IllegalArgumentException("�����������зǷ�����"+str);
			}
			num = checkLargeNum(num);
			checkNegative(num);
			
			sum+=num;
		}
		return sum;
		
	}

	private static int checkLargeNum(int num) {
		if(num>MAX_VALUE){
			num=0;
		}
		return num;
	}

	private static void checkNegative(int num) {
		if(num<0){
			throw new IllegalArgumentException("��������Ϊ����,����"+num);
		}
	}

	private static String[] splitString(String number) {
		String[] splitStrings = number.split(",");
		return splitStrings;
	}

	private static boolean isEmpty(String number) {
		return "".equals(number.trim());
	}

	private static boolean isNull(String number) {
		return number==null;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	int sum=0;
//	if(number==null){
//		return 0;
//	}
//	if("".equals(number.trim())){
//		return 0;
//	}
//	String[] splitStringNums = number.split("[*;,\n]");
//	for (String sNum : splitStringNums) {
//		int num;
//		try {
//			num=Integer.parseInt(sNum);
//		} catch (Exception e) {
//			throw new IllegalArgumentException("�����������зǷ�����"+sNum);
//		}
//		
//		if(num>1000){
//			num=0;
//		}
//		if(num<0){
//			throw new IllegalArgumentException("��������Ϊ����,����"+num);
//		}
//		sum+=num;
//	}
//	System.out.println("sum:"+sum);
//	return sum;
	
}
