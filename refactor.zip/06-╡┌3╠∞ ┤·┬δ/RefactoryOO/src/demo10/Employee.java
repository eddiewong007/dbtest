package demo10;

public class Employee {
	private String _id;
	private String _name;
	private int _annualCost;

	public Employee(String name, String id, int annualCost) {
		_name = name;
		_id = id;
		_annualCost = annualCost;
	}

	
	void test(){
		int age=0;
		System.out.print("age=  "+age);
	}
}
